# 收并购分析套件 (MA Analysis Kit)

> 一套标准化、可迁移的公司收并购分析工作流程
> 
> 版本: 1.0.0 | 更新时间: 2026-03-12

## 📦 套件组成

```
ma-analysis-kit/
├── README.md                 # 本文件 - 使用指南
├── WORKFLOW.md              # 主流程文档
├── skills/
│   └── ma-analysis/         # AI Skill 定义
│       └── SKILL.md
├── templates/               # 分析模板
│   ├── report-template.md   # 报告模板
│   ├── financial-model.xlsx # 财务模型模板
│   └── valuation-matrix.md  # 估值矩阵模板
├── checklists/              # 检查清单
│   ├── data-collection.md   # 数据收集清单
│   ├── legal-review.md      # 法律审查清单
│   └── quality-control.md   # 质量控制清单
├── scripts/                 # 自动化脚本
│   ├── data_collector.py    # 数据采集脚本
│   ├── analysis_helper.py   # 分析辅助脚本
│   └── report_generator.py  # 报告生成脚本
└── examples/                # 示例
    ├── sample-report.md     # 示例报告
    └── sample-analysis/     # 完整分析案例
```

## 🚀 快速开始

### 方式一: 使用 AI Code 工具 (Claude/Kimi)

1. **复制 Skill 文件**
   ```bash
   # Claude Code
   cp -r skills/ma-analysis ~/.claude/skills/
   
   # Kimi Code
   cp -r skills/ma-analysis ~/.kimi/skills/
   ```

2. **启动分析**
   ```
   @ma-analysis 分析 [公司名称]
   ```

### 方式二: 手动流程

1. 阅读 `WORKFLOW.md` 了解完整流程
2. 使用 `checklists/` 中的清单指导数据收集
3. 使用 `templates/` 中的模板编写报告

### 方式三: 自动化脚本

```bash
# 安装依赖
pip install -r scripts/requirements.txt

# 运行数据采集
python scripts/data_collector.py --company "公司名称"

# 生成分析报告
python scripts/report_generator.py --input data/ --output report.md
```

## 📋 标准工作流程

```mermaid
阶段1: 数据收集
├── 工商信息
├── 财务报表
├── 新闻舆情
└── 内部资料

阶段2: 数据处理
├── 数据清洗
├── 交叉验证
└── 缺失补充

阶段3: 分析建模
├── 财务分析
├── 估值建模
├── 风险识别
└── 行业对标

阶段4: 报告输出
├── 执行摘要
├── 详细分析
├── 风险提示
└── 交易建议
```

## 🔌 MCP 数据源配置

### 支持的 MCP 服务

| 服务 | 类型 | 用途 | 配置方式 |
|------|------|------|---------|
| Daloopa | 财务数据 | 财务建模 | HTTP MCP |
| FactSet | 综合数据 | 机构级分析 | HTTP MCP |
| PitchBook | 私募数据 | 一级市场交易 | HTTP MCP |
| 天眼查 | 工商数据 | 股权结构 | API |
| Wind/同花顺 | 金融终端 | A股数据 | API |

### MCP 配置示例

```json
{
  "mcpServers": {
    "daloopa": {
      "url": "https://mcp.daloopa.com/server/mcp",
      "headers": { "Authorization": "Bearer ${DALOOPA_TOKEN}" }
    },
    "factset": {
      "url": "https://mcp.factset.com/mcp",
      "headers": { "Authorization": "Bearer ${FACTSET_TOKEN}" }
    }
  }
}
```

## 📊 输出物标准

每个分析项目必须生成:

1. **执行摘要** (1页) - 关键发现和建议
2. **详细报告** (10-20页) - 完整分析
3. **财务模型** (Excel) - 三表+估值模型
4. **数据底稿** (文件夹) - 所有原始数据
5. **风险提示清单** (表格) - 风险点及应对

## 🔄 迁移指南

### 迁移到 Claude Code
```bash
# 1. 复制技能目录
cp -r skills/ma-analysis ~/.claude/skills/

# 2. 配置 MCP
claude mcp add --transport http daloopa https://mcp.daloopa.com/server/mcp

# 3. 使用
claude
> @ma-analysis 分析目标公司
```

### 迁移到 Kimi Code
```bash
# 1. 复制技能目录
cp -r skills/ma-analysis ~/.kimi/skills/

# 2. 使用
kimi
> @ma-analysis 分析目标公司
```

### 迁移到 OpenClaw
```bash
# 1. 复制到配置目录
cp -r skills/ma-analysis ~/.openclaw/skills/

# 2. 重启 OpenClaw
openclaw
```

### 迁移到云端/服务器
```bash
# 1. 打包
zip -r ma-analysis-kit.zip ma-analysis-kit/

# 2. 上传到服务器
scp ma-analysis-kit.zip user@server:/path/

# 3. 解压使用
unzip ma-analysis-kit.zip
```

## 📝 使用示例

### 示例 1: 分析一家非上市公司

```
@ma-analysis
目标公司: 广东横琴深水云科数字科技有限公司
统一信用代码: 91440101MA9Y5F6000
已知信息:
- 母公司: 盈峰集团
- 注册资本: 500万
- 业务: 金融科技外包

请生成完整的收并购分析报告
```

### 示例 2: 分析一家上市公司

```
@ma-analysis
目标公司: 深水规院 (301038.SZ)
分析目的: 评估收购价值
重点关注:
- 财务健康状况
- 股权结构
- 法律风险

请生成投资分析报告
```

## ⚠️ 免责声明

1. 本套件提供的分析框架和工具仅供学习研究使用
2. 所有数据来源于公开渠道，不构成投资建议
3. 使用前请确保遵守相关法律法规和数据使用协议
4. 内部数据分析需获得授权，注意信息保密

## 📚 相关资源

- [MCP 协议文档](https://modelcontextprotocol.io/)
- [Claude Code 文档](https://docs.anthropic.com/en/docs/claude-code/overview)
- [Kimi Code 文档](https://kimi.com/docs)

## 🤝 贡献

欢迎提交 Issue 和 PR 改进本套件

## 📄 许可证

MIT License
