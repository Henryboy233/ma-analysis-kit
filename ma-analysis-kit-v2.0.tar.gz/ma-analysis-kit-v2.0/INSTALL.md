# 快速安装说明

## 1. 解压
```bash
tar -xzvf ma-analysis-kit-v2.0.tar.gz
cd ma-analysis-kit-v2.0
```

## 2. 安装依赖
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r app_requirements.txt
```

## 3. 配置API
```bash
cp config/.env.example config/.env
# 编辑 config/.env，填入你的Tushare Token
```

## 4. 启动
```bash
./start_app.sh
```

## 5. 访问
浏览器打开：http://localhost:8501

---
详细说明见：DEPLOY_GUIDE.md
