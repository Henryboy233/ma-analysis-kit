# 收并购分析套件 - 文件清单

## 核心文档

| 文件 | 说明 | 必需 |
|------|------|------|
| `README.md` | 主文档，使用指南 | ✓ |
| `WORKFLOW.md` | 标准工作流程文档 | ✓ |
| `MIGRATION.md` | 迁移指南 | ✓ |
| `QUICKSTART.sh` | 快速开始脚本 | ✓ |
| `verify.sh` | 环境验证脚本 | ✓ |
| `MANIFEST.md` | 本文件 | |

## 技能定义

| 文件 | 说明 | 必需 |
|------|------|------|
| `skills/ma-analysis/SKILL.md` | AI Skill 定义文件 | ✓ |

## 模板

| 文件 | 说明 | 必需 |
|------|------|------|
| `templates/report-template.md` | 分析报告模板 | ✓ |

## 检查清单

| 文件 | 说明 | 必需 |
|------|------|------|
| `checklists/data-collection.md` | 数据收集检查清单 | ✓ |

## 脚本

| 文件 | 说明 | 必需 |
|------|------|------|
| `scripts/data_collector.py` | 数据采集脚本 | ✓ |
| `scripts/report_generator.py` | 报告生成脚本 | ✓ |
| `scripts/requirements.txt` | Python依赖列表 | ✓ |

## 总文件数

- Markdown 文档: 6
- Python 脚本: 2
- Shell 脚本: 2
- 配置文件: 1
- **总计: 11 个文件**

## 文件大小统计

```bash
# 查看各目录大小
du -sh ~/ma-analysis-kit/*

# 查看总大小
du -sh ~/ma-analysis-kit/
```

## 完整性校验

运行以下命令验证套件完整性:

```bash
cd ~/ma-analysis-kit
./verify.sh
```

## 备份建议

建议定期备份以下内容:

1. **套件本身**: `~/ma-analysis-kit/` 目录
2. **项目数据**: `~/ma-analysis-kit/projects/` 目录
3. **配置文件**: `ma-config.json`

备份命令:

```bash
# 打包备份
tar -czvf ma-analysis-kit-backup-$(date +%Y%m%d).tar.gz \
  ~/ma-analysis-kit/

# 或使用 git
cd ~/ma-analysis-kit
git add .
git commit -m "Backup $(date -I)"
git push
```

## 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| 1.0.0 | 2026-03-12 | 初始版本 |

---

**注意**: 本套件不含任何商业数据或敏感信息，可自由复制和迁移。
